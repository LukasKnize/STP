<?php 
get_header('landing');
?>
    <main class="mainLanding">
        <div id="importantInfo">
            <h2>Aktuality</h2>
            <div class="importantInfoHolder">
                <div class="importantInfoContainer" id="LineBorder">
                    <div class="InfoContainer">
                        <img src="images/report_problem_black_24dp.svg" alt="">
                        <div class="importantInfoText">
                            <h4>Lorem ipsum</h4>
                            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dignissimos, facere rerum non
                                qui explicabo sunt delectus a mollitia harum iste provident repudiandae temporibus
                                eveniet eos quibusdam ex laudantium dolorem numquam?</p>
                        </div>
                    </div>
                    <div class="InfoContainer">
                        <img src="images/report_problem_black_24dp.svg" alt="">
                        <div class="importantInfoText">
                            <h4>Lorem ipsum</h4>
                            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dignissimos, facere rerum non
                                qui explicabo sunt delectus a mollitia harum iste provident repudiandae temporibus
                                eveniet eos quibusdam ex laudantium dolorem numquam?</p>
                        </div>
                    </div>
                </div>
                <div class="importantInfoContainer">
                    <div class="InfoContainer">
                        <img src="images/report_problem_black_24dp.svg" alt="">
                        <div class="importantInfoText">
                            <h4>Lorem ipsum</h4>
                            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dignissimos, facere rerum non
                                qui explicabo sunt delectus a mollitia harum iste provident repudiandae temporibus
                                eveniet eos quibusdam ex laudantium dolorem numquam?</p>
                        </div>
                    </div>
                    <div class="InfoContainer">
                        <img src="images/report_problem_black_24dp.svg" alt="">
                        <div class="importantInfoText">
                            <h4>Lorem ipsum</h4>
                            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dignissimos, facere rerum non
                                qui explicabo sunt delectus a mollitia harum iste provident repudiandae temporibus
                                eveniet eos quibusdam ex laudantium dolorem numquam?</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="quickMenu">
            <div class="quickMenuContainer">
                <a href="./pageForm.html">
                    <div class="menuItem">
                        <div class="iconContainer">
                            <img src="images/account_balance_black_24dp.svg" alt="">
                        </div>
                        <p>ŠKOLA</p>
                    </div>
                </a>
                <a href="./teachersMenu.html">
                <div class="menuItem">
                    <div class="iconContainer">
                        <img src="images/school_black_24dp.svg" alt="">
                    </div>
                    <p>UČITELÉ</p>
                </div>
            </a>
            <a href="./akceMenu.html">
                <div class="menuItem">
                    <div class="iconContainer">
                        <img src="images/event_black_24dp.svg" alt="">
                    </div>
                    <p>AKCE</p>
                </div>
            </a>
            <a href="./systemy.html">
                <div class="menuItem">
                    <div class="iconContainer">
                        <img src="images/cast_for_education_black_24dp.svg" alt="">
                    </div>
                    <p>SYSTÉMY</p>
                </div>
            </a>
            </div>
        </div>
    </main>
    <?php
    get_footer();
    ?>
