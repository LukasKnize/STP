<?php 
get_header();
?>
    <main class="mainAkce">
        <div class="mainContainer">
            <article>
                <h1>
                    TEST TEXT
                </h1>
                <p class="articleText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium suscipit
                    numquam, porro ducimus aut molestiae officiis totam repellendus autem eos hic doloremque repellat
                    ratione deserunt reprehenderit assumenda. Necessitatibus, officia odio.Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium suscipit numquam, porro ducimus aut molestiae officiis
                    totam repellendus autem eos hic doloremque repellat ratione deserunt reprehenderit assumenda.
                    Necessitatibus, officia odio.</p>
                <p class="articleText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium suscipit
                    numquam, porro ducimus aut molestiae officiis totam repellendus autem eos hic doloremque repellat
                    ratione deserunt reprehenderit assumenda. Necessitatibus, officia odio.</p>
                <p class="articleText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium suscipit
                    numquam, porro ducimus aut molestiae officiis totam repellendus autem eos hic doloremque repellat
                    ratione deserunt reprehenderit assumenda. Necessitatibus, officia odio.Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium suscipit numquam, porro ducimus aut molestiae officiis
                    totam repellendus autem eos hic doloremque repellat ratione deserunt reprehenderit assumenda.
                    Necessitatibus, officia odio. Accusantium suscipit numquam, porro ducimus aut molestiae officiis
                    totam repellendus autem eos hic doloremque repellat ratione deserunt reprehenderit assumenda.
                    Necessitatibus, officia odio.Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium
                    suscipit numquam, porro ducimus aut molestiae officiis totam repellendus autem eos hic doloremque
                    repellat ratione deserunt reprehenderit assumenda. Necessitatibus, officia odio.</p>
                <p class="articleText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium suscipit
                    numquam, porro ducimus aut molestiae officiis totam repellendus autem eos hic doloremque repellat
                    ratione deserunt reprehenderit assumenda. Necessitatibus, officia odio.Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium suscipit numquam, porro ducimus aut molestiae officiis
                    totam repellendus autem eos hic doloremque repellat ratione deserunt reprehenderit assumenda.
                    Necessitatibus, officia odio.</p>
            </article>
            <aside>
                <h2>quick info</h2>
                <div class="sideText">
                    <p class="category">Název:</p>
                    <p class="info">Den otevřených dveří</p>
                </div>
                <div class="sideText">
                    <p class="category">Koordinátor akce:</p>
                    <p class="info">Michael Kalista</p>
                </div>
                <div class="sideText">
                    <p class="category">Datum konání:</p>
                    <p class="info">1.12.2021</p>
                </div>
                <div class="sideText">
                    <p class="category">Místo konání:</p>
                    <p class="info">Budova Školy</p>
                </div>
                <div class="sideText">
                    <p class="category">Koho se akce týká:</p>
                    <p class="info">Akce je pro každého kdo by chtěl reprezentovat školu během dne otevřených dveři</p>
                </div>
            </aside>
        </div>
    </main>
    <?php
    get_footer();
    ?>